# N3K0P01 HUB — Script List

Website katalog script statis berbasis HTML/CSS/JavaScript, dibuat dari template Launch dan disesuaikan untuk N3K0P01 HUB.

## Menjalankan

Buka `index.html` di browser atau unggah isi folder ini ke layanan hosting static seperti GitHub Pages / Netlify.

## Penting sebelum dipublikasikan

1. Buka `index.html`.
2. Cari `data-copy-link="GANTI_DENGAN_LINK_..."` pada setiap kartu.
3. Ganti nilai placeholder tersebut dengan URL script yang sebenarnya. Tombol **Salin Link** akan menyalin URL itu.
4. Periksa status, nama, deskripsi, dan tautan Discord pada `contact.html`.

Pencarian dan salin link menggunakan JavaScript sisi browser. Template ini tidak menyediakan backend, autentikasi admin, atau database. Navigasi antarhalaman dan menu mobile sudah disediakan.

Lisensi sumber template: lihat `LICENSE.txt`.
